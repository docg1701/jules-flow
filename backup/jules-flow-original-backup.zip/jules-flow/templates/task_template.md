---
id: TASK-000
title: "Título Curto e Descritivo da Tarefa"
epic: "Fase X: Nome do Épico do Roadmap"
type: "development" # Tipos: development, research, test, documentation, review
status: backlog
priority: medium
dependencies: []
assignee: Jules
---

### Descrição

(Descrição detalhada do objetivo da tarefa)

### Critérios de Aceitação

- [ ] Critério 1 que define 'pronto'.
- [ ] Critério 2 que define 'pronto'.

### Arquivos Relevantes

* `caminho/para/arquivo1.py`

### Relatório de Execução

(Esta seção deve ser deixada em branco no template)
